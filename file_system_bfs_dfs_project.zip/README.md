# File System Representation and Search Using BFS and DFS

## Overview
This C program represents a simplified file system as a directed graph.
Each file or directory is a vertex (node), and each parent-to-child
relationship is an edge. The graph is stored using an adjacency matrix.

The program performs:
- Breadth-First Search (BFS) using a queue.
- Depth-First Search (DFS) using recursion.
- A search for a requested file/folder during both traversals.

## Files
- `file_system_bfs_dfs.c` — complete C source code
- `sample_input.txt` — sample input
- `sample_output.txt` — corresponding sample output

## How to compile and run
Using GCC:

```bash
gcc file_system_bfs_dfs.c -o file_search
./file_search
```

On Windows with GCC:

```bash
gcc file_system_bfs_dfs.c -o file_search.exe
file_search.exe
```

## Input format
1. Number of nodes.
2. One name for each node (use one word per name).
3. An N x N adjacency matrix. `1` means an edge exists; `0` means no edge.
4. Starting node index.
5. Name of the file/folder to search.

The matrix is directed: a `1` at row `i`, column `j` means there is an edge
from node `i` to node `j`.

## Sample graph
Root connects to Documents and Pictures. Documents connects to Notes.txt.
Pictures connects to Photo.jpg.

Node indices:
- 0 — Root
- 1 — Documents
- 2 — Pictures
- 3 — Notes.txt
- 4 — Photo.jpg

## Notes
- Maximum supported nodes: 50.
- Enter file/folder names without spaces.
- Traversal starts at the selected node and visits only nodes reachable from it.
